a) Full Name: Ethan Soinpung Chan
b) Student ID: 1801654130
c) Completed Phase III
d) General compares the two success rates of the two captains and opens a TCP connection to each captain. Each Captain in turn opens a TCP connection to listen to the command of the General before the General initiates the commands. The General first tells the Captain with the higher success rate to begin the mission and then tells the other Captain to go on the mission as backup.
e) First download all the files into the same folder. Type "make" in the compiler. Run executable "./Major. Then run executable ./General Then run either executable "./Captain1" or "./Captain2" in either order. If the password in the passMj.txt do not match the password in passGn.txt,  download the correct passMj.txt and type 'y' in the Major terminal to the prompt "Do you want to try resending password to general? (y/n) to resend the correct password.
f) Format is the same as the table. Every time there is a connection or transfer of data, it is printed on the Major's screen.
g) Project works up to perhaps 5 digit resource/confidence numbers. :) I have created delays ("sleep()") from 5 seconds to 20 seconds so please be patient as the code runs.
h) Used code from Beej Manual and "http://stackoverflow.com/questions/6659858/how-to-find-a-sockets-local-port-number-windows-c" to understand getsockname().