a) Full Name: Ethan Soinpung Chan
b) Student ID: 1801654130
c) Completed Phase I
d) Captain1.cpp and Captain2.cpp have codes that read their own Captain1.txt and Captain2.txt files respectively and sends them to Major.cpp file which prints the files on the screen. Captain1.h, Captain2.h, and Major.h are the header files. Makefile is the make file.
e) First download all the files into the same folder. Type "make" in the compiler. Run executable "./Major" and then run either executable "./Captain1" or "./Captain2" in either order.
f) Format is the same as the table. Every time there is a connection or transfer of data, it is printed on the Major's screen.
g) Project works (THIS IS THE UPDATED FILE USE THIS ONE)
h) Used code from Beej Manual and "http://stackoverflow.com/questions/6659858/how-to-find-a-sockets-local-port-number-windows-c" to understand getsockname().