{\rtf1\ansi\ansicpg1252\cocoartf1038\cocoasubrtf360
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural

\f0\fs24 \cf0 i) Ethan Soinpun Chan\
Student ID: 1801654130\
\
ii) Compile program with the following script: g++ -g -Wall -o lab1 lab1.cpp\
run program with the following script: ./lab1\
Program will ask you for the starting node. Simply input one of the following inputs: A, a, B, b, C, c, D, d, E, e, F, f\
\
iii) Working somewhat with a glitch\
\
Iv) My code is commented and I have created cout flags that have been commented out but can be used by simply uncommenting them if an error were to occur. I used these couts (flags) to debug.\
\
The lab does not have the all  the updated correct results.}